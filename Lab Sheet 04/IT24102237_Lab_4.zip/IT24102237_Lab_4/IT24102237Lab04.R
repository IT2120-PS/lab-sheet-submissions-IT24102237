
setwd("C:\\Users\\IT24102237\\Desktop\\IT24102237_Lab_4")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

boxplot(branch_data$Sales, main = "Boxplot of Sales", ylab = "Sales")
head(branch_data)
boxplot(branch_data$Sales, main = "Boxplot of Sales", ylab = "Sales", col = "yellow")

fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)

find_outliers <- function(X) {
    Q1 <- quantile(X, 0.25)
    Q3 <- quantile(X, 0.75)
    IQR <- Q3 - Q1

    lower <- Q1 - 1.5 * IQR
    upper <- Q3 + 1.5 * IQR

    Outliers <- X[X < lower | X > upper]
    return(Outliers)
}

outliers_advertising <- find_outliers(branch_data$Advertising)
print(outliers_advertising)

